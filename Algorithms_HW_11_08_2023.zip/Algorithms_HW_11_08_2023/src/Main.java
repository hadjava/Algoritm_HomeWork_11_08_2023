import java.util.Stack;

class SpecialStack {
    private Stack<Integer> stack;
    private Stack<Integer> minStack;

    public SpecialStack() {
        stack = new Stack<>();
        minStack = new Stack<>();
    }

    // Добавление элемента в стек
    public void push(int x) {
        stack.push(x);

        if (minStack.isEmpty() || x <= getMin()) {
            minStack.push(x);
        }
    }

    // Удаление элемента из стека
    public void pop() {
        if (!stack.isEmpty()) {
            int popped = stack.pop();
            if (popped == getMin()) {
                minStack.pop();
            }
        }
    }

    // Получение верхнего элемента стека
    public int top() {
        if (!stack.isEmpty()) {
            return stack.peek();
        }
        throw new IllegalStateException("Stack is empty");
    }

    // Получение минимального элемента стека
    public int getMin() {
        if (!minStack.isEmpty()) {
            return minStack.peek();
        }
        throw new IllegalStateException("Stack is empty");
    }

    // Проверка, пуст ли стек
    public boolean isEmpty() {
        return stack.isEmpty();
    }
}

public class Main {
    public static void main(String[] args) {
        SpecialStack specialStack = new SpecialStack();

        specialStack.push(3);
        System.out.println("Top: " + specialStack.top()); // 3
        System.out.println("Min: " + specialStack.getMin()); // 3

        specialStack.push(5);
        System.out.println("Top: " + specialStack.top()); // 5
        System.out.println("Min: " + specialStack.getMin()); // 3

        specialStack.push(2);
        System.out.println("Top: " + specialStack.top()); // 2
        System.out.println("Min: " + specialStack.getMin()); // 2

        specialStack.pop();
        System.out.println("Top: " + specialStack.top()); // 5
        System.out.println("Min: " + specialStack.getMin()); // 3
    }
}